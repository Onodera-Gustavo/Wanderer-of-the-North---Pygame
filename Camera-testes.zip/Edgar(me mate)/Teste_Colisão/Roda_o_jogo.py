import pygame
from mapa import Map
from player import Player, Dash

class Game:
    def __init__(self):
        # Inicializa o pygame
        pygame.init()
        self.tela = pygame.display.set_mode((1280, 720))
        pygame.display.set_caption('Teste de Transição de Mapas')

        # Dicionário de mapas
        self.maps = {
            "map1": Map('MAP(1) - COMPLET.tmx'),
            "map2": Map('MAP(2) - COMPLET.tmx')
        }
        self.current_map = "map1"  # Mapa inicial
        self.mapa = self.maps[self.current_map]

        # Grupo de sprites
        self.sprites = pygame.sprite.Group()
        
        # Criar o jogador no centro do mapa inicial
        spawn_x = self.mapa.width // 2
        spawn_y = self.mapa.height // 2
        self.player = Player((spawn_x, spawn_y), self.sprites)

        self.clock = pygame.time.Clock()
        self.camera_offset = [0, 0]
        self.camera_surface = pygame.Surface((1280, 720))
        self.transition_cooldown = 0

    def calculate_camera_offset(self):
        """Centraliza a câmera no jogador com suavização"""
        target_x = self.player.rect.centerx - self.tela.get_width() // 2
        target_y = self.player.rect.centery - self.tela.get_height() // 2
        
        # Suavização da câmera
        self.camera_offset[0] += (target_x - self.camera_offset[0]) * 0.1
        self.camera_offset[1] += (target_y - self.camera_offset[1]) * 0.1
        
        # Limitar câmera aos limites do mapa
        self.camera_offset[0] = max(0, min(self.camera_offset[0], self.mapa.width - self.tela.get_width()))
        self.camera_offset[1] = max(0, min(self.camera_offset[1], self.mapa.height - self.tela.get_height()))
    
    def draw(self):
        """Desenha tudo na tela incluindo transições"""
        self.tela.fill((0, 0, 0))
        self.camera_surface.fill((0, 0, 0))
        
        # Desenha o estado atual do jogo
        if hasattr(self, 'transition_data'):
            # Durante transição: desenha ambos os estados
            transition = self.transition_data
            
            # 1. Desenha o NOVO estado (usando o mapa novo temporariamente)
            old_map = self.current_map
            self.current_map = transition['new_map']
            self.mapa = self.maps[self.current_map]
            
            self.mapa.draw(self.camera_surface, self.player, self.camera_offset)
            new_surface = pygame.Surface((1280, 720))
            new_surface.blit(self.camera_surface, (0, 0))
            
            # Volta para o mapa antigo para continuar a lógica
            self.current_map = old_map
            self.mapa = self.maps[self.current_map]
            
            # 2. Prepara a tela final
            self.tela.blit(new_surface, (0, 0))
            
            # 3. Sobrepoe o estado antigo com fade out
            alpha = int(255 * (1 - transition['progress']))
            transition['old_surface'].set_alpha(alpha)
            self.tela.blit(transition['old_surface'], (0, 0))
        else:
            # Estado normal do jogo
            self.mapa.draw(self.camera_surface, self.player, self.camera_offset)
            self.tela.blit(self.camera_surface, (0, 0))
        
        pygame.display.flip()
    
    def update(self):
        """Atualiza a lógica do jogo incluindo transições"""
        if self.transition_cooldown > 0:
            self.transition_cooldown -= 1
                
        # Passa o sistema de colisão para o player
        self.player.update(self.mapa, self.camera_offset)
        self.calculate_camera_offset()
            
        # Atualiza a transição se estiver ativa
        if hasattr(self, 'transition_data') and self.transition_data['active']:
            self.update_transition()
        else:
            self.handle_map_transitions()

    def update_transition(self):
        """Atualiza o estado da transição"""
        transition = self.transition_data
        transition['progress'] += 1 / (60 * transition['duration'])
        
        # Quando a transição terminar
        if transition['progress'] >= 1:
            # Efetiva a mudança de mapa
            self.current_map = transition['new_map']
            self.mapa = self.maps[self.current_map]
            
            # Reposiciona o jogador
            if transition['old_map'] == "map1" and transition['new_map'] == "map2":
                self.player.rect.midbottom = (transition['player_pos'][0], self.mapa.height - 20)
            elif transition['old_map'] == "map2" and transition['new_map'] == "map1":
                self.player.rect.midtop = (transition['player_pos'][0], 20)
            
            
            # Finaliza a transição
            del self.transition_data

    def run(self):
        """Loop principal do jogo"""
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()

            self.update()
            self.draw()
            self.clock.tick(60)

    def change_map(self, new_map):
        """Prepara a transição de mapas sem bloquear o game loop"""
        if self.transition_cooldown > 0 or new_map not in self.maps:
            return

        # Configuração da transição
        self.transition_data = {
            'active': True,
            'duration': 0.5,  # segundos
            'progress': 0,
            'old_surface': pygame.Surface((1280, 720)),
            'old_map': self.current_map,
            'new_map': new_map
        }
        
        # Captura o estado atual antes da transição
        self.transition_data['old_surface'].blit(self.camera_surface, (0, 0))
        
        # Prepara o novo mapa (mas não muda ainda)
        self.transition_cooldown = 120
        self.transition_data['player_pos'] = self.player.rect.center


    def handle_map_transitions(self):
        """Verifica se o jogador atingiu os limites do mapa"""
        if self.transition_cooldown > 0:
            return
            
        margin = 10  # Margem de segurança
        

        # Transição pela borda superior
        if (self.player.rect.top <= margin and 
            self.current_map == "map1"):
            self.change_map("map2")
            

        # Transição pela borda inferior
        elif (self.player.rect.bottom >= self.mapa.height - margin and 
            self.current_map == "map2"):
            self.change_map("map1")
            
        
      

if __name__ == "__main__":
    jogo = Game()
    jogo.run()
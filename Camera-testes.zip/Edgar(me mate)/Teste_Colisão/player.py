import pygame
import math


class Dash:
    def __init__(self, dash_speed=10, dash_time=10, cooldown=60):
        self.dash_speed = dash_speed
        self.dash_time = dash_time
        self.cooldown = cooldown
        self.dashing = False
        self.dash_timer = 0
        self.cooldown_timer = 0

    def start_dash(self):
        if self.cooldown_timer == 0 and not self.dashing:
            self.dashing = True
            self.dash_timer = self.dash_time
            self.cooldown_timer = self.cooldown

    def update(self):
        if self.dashing:
            self.dash_timer -= 1
            if self.dash_timer <= 0:
                self.dashing = False

        if self.cooldown_timer > 0:
            self.cooldown_timer -= 1



class Player(pygame.sprite.Sprite):
    def __init__(self, pos, group):
        super().__init__(group)
        original_image = pygame.image.load('graphics\pixil-frame-0 (2).png').convert_alpha()
        
        self.image = pygame.transform.scale(original_image, (original_image.get_width()//5, original_image.get_height()//5))
        self.rect = self.image.get_rect(center=pos)
        self.direction = pygame.math.Vector2()
        self.speed = 3.5
        self.dash = Dash()
        self.health = 100
        self.shield = 100

    def movimentacao(self, mapa, camera_offset):
    # Mova a leitura de inputs para antes do movimento
        keys = pygame.key.get_pressed()
        
        # Atualize a direção primeiro
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            self.direction.y = -1
        elif keys[pygame.K_DOWN] or keys[pygame.K_s]:
            self.direction.y = 1
        else:
            self.direction.y = 0

        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.direction.x = 1
        elif keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.direction.x = -1
        else:
            self.direction.x = 0

        if keys[pygame.K_q]:
            self.dash.start_dash()

        
            # Normaliza movimento diagonal
        if self.direction.length() > 0:
            self.direction = self.direction.normalize()

        vel = self.speed + (self.dash.dash_speed if self.dash.dashing else 0)
        
        # Testa movimento X
        original_pos = self.rect.copy()
        self.rect.x += self.direction.x * vel
        if mapa.check_collision(self.rect, camera_offset):
            self.rect.x = original_pos.x
        
        # Testa movimento Y
        self.rect.y += self.direction.y * vel
        if mapa.check_collision(self.rect, camera_offset):
            self.rect.y = original_pos.y

    def update(self, mapa=None, camera_offset=(0,0)):
        self.dash.update()
        if mapa:
            self.movimentacao(mapa, camera_offset)

   


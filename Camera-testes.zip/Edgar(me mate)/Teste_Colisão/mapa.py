import pygame
from pytmx import load_pygame, TiledTileLayer



class Map:
    def __init__(self, tmx_file):
        self.tmx_data = load_pygame(tmx_file)
        self.width = self.tmx_data.width * self.tmx_data.tilewidth
        self.height = self.tmx_data.height * self.tmx_data.tileheight
        
       
    def check_collision(self, player_rect, camera_offset=(0, 0)):
        """Verifica colisão com objetos em Object Layers"""
        # Debug: mostra todos os objetos na camada
        objects_in_layer = []
        for layer in self.tmx_data.visible_layers:
            if hasattr(layer, 'objects') and layer.name == "Object Layer 1":
                objects_in_layer = list(layer.objects.values())
                break
        
        print(f"Objetos encontrados: {len(objects_in_layer)}")
        
        for obj in objects_in_layer:
            # Converte o objeto para um retângulo pygame
            obj_rect = pygame.Rect(obj.x, obj.y, obj.width, obj.height)
            
            # Converte o player_rect (tela) para coordenadas de mundo
            world_player_rect = player_rect.move(camera_offset[0], camera_offset[1])
            
            if world_player_rect.colliderect(obj_rect):
                print(f"Colisão detectada! Player: {world_player_rect}, Objeto: {obj_rect}")
                return True
        
        return False
    
    def draw(self, tela, player, camera_offset):

        """Desenha o mapa com YSorting"""
        # Lista de camadas que devem usar YSort
        ysort_layers = []  # Adapte para suas camadas
        
        # Lista de sprites (incluindo o player) para ordenação Y
        all_sprites = []
        
        # Primeiro desenhe as camadas base (que não usam YSort)
        for layer in self.tmx_data.visible_layers:
            if isinstance(layer, TiledTileLayer) and layer.name not in ysort_layers:
                for x, y, gid in layer:
                    tile = self.tmx_data.get_tile_image_by_gid(gid)
                    if tile:
                        pos_x = x * self.tmx_data.tilewidth - camera_offset[0]
                        pos_y = y * self.tmx_data.tileheight - camera_offset[1]
                        tela.blit(tile, (pos_x, pos_y))
        
        # Coletar sprites e tiles para YSort
        for layer in self.tmx_data.visible_layers:
            if isinstance(layer, TiledTileLayer) and layer.name in ysort_layers:
                for x, y, gid in layer:
                    tile = self.tmx_data.get_tile_image_by_gid(gid)
                    if tile:
                        all_sprites.append({
                            'image': tile,
                            'rect': pygame.Rect(
                                x * self.tmx_data.tilewidth,
                                y * self.tmx_data.tileheight,
                                tile.get_width(),
                                tile.get_height()
                            )
                        })
        
        # Adicionar o player à lista de sprites para ordenação
        all_sprites.append({
            'image': player.image,
            'rect': player.rect
        })
        
        # Ordenar sprites por posição Y (YSorting)
        all_sprites.sort(key=lambda sprite: sprite['rect'].centery)
        
        # Desenhar sprites ordenados
        for sprite in all_sprites:
            pos_x = sprite['rect'].x - camera_offset[0]
            pos_y = sprite['rect'].y - camera_offset[1]
            tela.blit(sprite['image'], (pos_x, pos_y))
        
        # Desenhar camadas que devem ficar por cima de tudo
        for layer in self.tmx_data.visible_layers:
            if isinstance(layer, TiledTileLayer) and layer.name in ["Extras","Bush", "Bush2", "Bush3", "Bush4","Mountaincave", "Fields2", "Fields3"]:
                for x, y, gid in layer:
                    tile = self.tmx_data.get_tile_image_by_gid(gid)
                    if tile:
                        pos_x = x * self.tmx_data.tilewidth - camera_offset[0]
                        pos_y = y * self.tmx_data.tileheight - camera_offset[1]
                        tela.blit(tile, (pos_x, pos_y))


    def Get_size(self):

        #Retorna as dimensões do mapa
        return self.width, self.height
    
    def draw_collision(self, surface, offset):
        for rect in self.collision_rects:
            adjusted_rect = rect.move(-offset[0], -offset[1])
            pygame.draw.rect(surface, (255, 0, 0), adjusted_rect, 1)
    
